document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.cp-carousel').forEach(function(carousel) {
        var id = carousel.getAttribute('data-id');
        if (!id) return;
        fetch(cpCarouselAjax.url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=cp_carousel_get&id=' + encodeURIComponent(id)
        })
        .then(r => r.json())
        .then(data => {
            if (!data.images || !data.images.length) {
                carousel.innerHTML = '<div class="cp-carousel-empty">Нет изображений</div>';
                return;
            }
            var slides = data.images.map(function(img, idx) {
                var slide = '<div class="swiper-slide">';
                slide += '<div class="cp-carousel-slide-img-wrap">';

                var currentImageUrl;
                if (window.innerWidth < 768 && img.mobile_url) {
                    currentImageUrl = img.mobile_url;
                } else if (img.pc_url) {
                    currentImageUrl = img.pc_url;
                } else if (img.mobile_url) {
                    currentImageUrl = img.mobile_url;
                } else {
                    currentImageUrl = '';
                }

                slide += '<img class="cp-carousel-img swiper-lazy" src="'+currentImageUrl+'" alt="" loading="lazy" />';
                
                if (img.link) {
                    slide += '<a href="' + img.link + '" target="_blank" rel="noopener noreferrer" class="cp-carousel-advertiser-link">Перейти на сайт рекламодателя</a>';
                }

                slide += '<div class="swiper-lazy-preloader"></div>';
                slide += '</div>';
                slide += '</div>';
                return slide;
            }).join('');
            var hasMultipleSlides = data.images.length > 1;
            var navigationMarkup = hasMultipleSlides
                ? '<div class="swiper-button-prev"></div><div class="swiper-button-next"></div>'
                : '';
            carousel.innerHTML = `
                <div class="swiper">
                    <div class="swiper-wrapper">${slides}</div>
                    ${navigationMarkup}
                </div>
            `;
            if (typeof Swiper === 'undefined') {
                console.error('CP Carousel: Swiper library is not loaded or failed to load. Carousel cannot be initialized for ID ' + id + '. Please check script loading errors in the console, especially for Swiper.js.');
                carousel.innerHTML = '<div class="cp-carousel-error" style="text-align:center; padding:20px; color:red;">Ошибка: Библиотека для слайдера (Swiper) не загружена. Карусель не может быть отображена.</div>';
                return;
            }

            var swiperConfig = {
                loop: hasMultipleSlides,
                autoplay: { delay: data.speed || 3000, disableOnInteraction: false },
                speed: 700,
                lazy: { loadPrevNext: true }
            };
            if (hasMultipleSlides) {
                swiperConfig.navigation = {
                    nextEl: carousel.querySelector('.swiper-button-next'),
                    prevEl: carousel.querySelector('.swiper-button-prev')
                };
            }

            var swiper = new Swiper(carousel.querySelector('.swiper'), swiperConfig);
        });
    });
});