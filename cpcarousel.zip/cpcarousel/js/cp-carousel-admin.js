jQuery(document).ready(function($){
    console.log('cp-carousel-admin.js loaded and ready.'); // Added for debugging

    function reindexImageFields() {
        $('#cp-carousel-images-list .cp-carousel-image-item').each(function(idx) {
            $(this).find('.cp-carousel-pc-url').attr('name', 'cp_carousel_images['+idx+'][pc_url]');
            $(this).find('.cp-carousel-mobile-url').attr('name', 'cp_carousel_images['+idx+'][mobile_url]');
            $(this).find('.cp-carousel-link').attr('name', 'cp_carousel_images['+idx+'][link]');
        });
    }

    function addImageField(pc_url = '', mobile_url = '', link = '') {
        var li = $('<li class="cp-carousel-image-item"></li>');
        var currentImageCount = $('#cp-carousel-images-list .cp-carousel-image-item').length;

        var header = $('<div class="cp-carousel-image-header"></div>');
        header.append($('<span></span>').text('Изображение #' + (currentImageCount + 1)));
        header.append($('<button type="button" class="button cp-carousel-toggle-details">Редактировать</button>'));
        header.append($('<button type="button" class="button cp-carousel-remove-image">Удалить</button>'));
        li.append(header);

        var preview = $('<div class="cp-carousel-image-preview"></div>');
        preview.append($('<img />').attr({
            'src': pc_url,
            'class': 'cp-carousel-pc-preview',
            'style': 'height:40px;vertical-align:middle;margin-right:5px;max-width:80px;object-fit:cover;border:1px solid #ccc;' + (pc_url ? '' : 'display: none;')
        }));
        preview.append($('<img />').attr({
            'src': mobile_url,
            'class': 'cp-carousel-mobile-preview',
            'style': 'height:40px;vertical-align:middle;max-width:80px;object-fit:cover;border:1px solid #ccc;' + (mobile_url ? '' : 'display: none;')
        }));
        li.append(preview);

        var details = $('<div class="cp-carousel-image-details" style="display: none;"></div>');
        details.append($('<p><strong>Изображение для ПК (1920x480):</strong></p>'));
        details.append($('<input type="text" class="cp-carousel-pc-url" style="width:60%" />').attr({
            'value': pc_url,
            'placeholder': 'URL или выберите из библиотеки'
        }));
        details.append($('<button type="button" class="button cp-carousel-select-media">Медиа</button>').data('target', 'pc_url'));
        details.append($('<p><strong>Изображение для Мобильных (1080x720):</strong></p>'));
        details.append($('<input type="text" class="cp-carousel-mobile-url" style="width:60%" />').attr({
            'value': mobile_url,
            'placeholder': 'URL или выберите из библиотеки'
        }));
        details.append($('<button type="button" class="button cp-carousel-select-media">Медиа</button>').data('target', 'mobile_url'));
        details.append($('<p><strong>Ссылка (необязательно):</strong></p>'));
        details.append($('<input type="text" class="cp-carousel-link" style="width:90%" />').attr({
            'value': link,
            'placeholder': 'Ссылка при клике (необязательно)'
        }));
        li.append(details);

        $('#cp-carousel-images-list').append(li);
        reindexImageFields();
    }

    reindexImageFields();

    $('#cp-carousel-add-image').on('click', function(e){
        e.preventDefault();
        console.log('Add Image button clicked.'); // Added for debugging
        addImageField();
    });

    $('#cp-carousel-images-list').on('click', '.cp-carousel-remove-image', function(){
        console.log('Remove Image button clicked.'); // Added for debugging
        $(this).closest('li').remove();
        reindexImageFields();
    });

    $('#cp-carousel-images-list').on('click', '.cp-carousel-toggle-details', function(){
        console.log('Toggle Details button clicked.'); // Added for debugging
        $(this).closest('.cp-carousel-image-item').find('.cp-carousel-image-details').slideToggle();
        var buttonText = $(this).text();
        if (buttonText === 'Редактировать') {
            $(this).text('Свернуть');
        } else {
            $(this).text('Редактировать');
        }
    });

    $('#cp-carousel-images-list').on('click', '.cp-carousel-select-media', function(e){
        e.preventDefault();
        console.log('Select Media button clicked.'); // Added for debugging
        var button = $(this);
        var targetField = button.data('target');
        var inputField = button.siblings('input[class*="cp-carousel-'+ targetField.replace('_url', '') +'"]');
        var previewImage = button.closest('.cp-carousel-image-item').find('.cp-carousel-' + targetField.replace('_url', '') + '-preview');

        var custom_uploader = wp.media({
            title: 'Выберите изображение',
            button: { text: 'Выбрать' },
            multiple: false
        })
        .on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            inputField.val(attachment.url);
            previewImage.attr('src', attachment.url).show();
        })
        .open();
    });
});