<?php
/*
Plugin Name: CP Carousel - Dynamic Image Slider
Plugin URI: https://copella.live/
Description: Современная, адаптивная карусель изображений с интуитивным управлением через админку. Включает поддержку мобильных устройств, навигацию стрелками и плавные переходы.
Version: 1.0
Author: Copella 2025, CP Carousel
Author URI: https://copella.live/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: cp-carousel
Domain Path: /languages
*/


if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


function cp_carousel_register_post_type() {
    register_post_type('cp_carousel', array(
        'labels' => array(
            'name' => 'Карусели',
            'singular_name' => 'Карусель',
            'add_new' => 'Добавить карусель',
            'add_new_item' => 'Добавить новую карусель',
            'edit_item' => 'Редактировать карусель',
            'new_item' => 'Новая карусель',
            'view_item' => 'Просмотр карусели',
            'search_items' => 'Искать карусели',
            'not_found' => 'Не найдено',
        ),
        'public' => false,
        'show_ui' => true,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => array('title'),
    ));
}
add_action('init', 'cp_carousel_register_post_type');


function cp_carousel_add_meta_boxes() {
    add_meta_box('cp_carousel_images', 'Изображения и ссылки', 'cp_carousel_images_box', 'cp_carousel', 'normal', 'high');
    add_meta_box('cp_carousel_settings', 'Настройки карусели', 'cp_carousel_settings_box', 'cp_carousel', 'side');
}
add_action('add_meta_boxes', 'cp_carousel_add_meta_boxes');




function cp_carousel_images_box($post) {
    $images = get_post_meta($post->ID, '_cp_carousel_images', true);
    $images = is_array($images) ? $images : array();
    echo '<div class="cp-shortcode-notice">'
        . 'Чтобы вставить эту карусель на сайт, используйте шорткод:<br>'
        . '<code id="cp-carousel-shortcode">[cp_carousel id="' . intval($post->ID) . '"]</code>'
        . '<button type="button" class="button" id="cp-carousel-copy-shortcode">Скопировать</button>'
        . '</div>';
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var btn = document.getElementById("cp-carousel-copy-shortcode");
        if(btn) {
            btn.addEventListener("click", function() {
                var code = document.getElementById("cp-carousel-shortcode").innerText;
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(code).then(function() {
                        var old = btn.innerText;
                        btn.innerText = "Скопировано!";
                        setTimeout(function(){ btn.innerText = old; }, 1200);
                    });
                }
            });
        }
    });
    </script>
    <?php
    echo '<div id="cp-carousel-images-admin">
        <button type="button" class="button" id="cp-carousel-add-image">Добавить изображение</button>
        <ul id="cp-carousel-images-list" class="ui-sortable">';
    foreach ($images as $i => $img) {
        $img_url = isset($img['url']) ? esc_url($img['url']) : '';
        $img_link = isset($img['link']) ? esc_url($img['link']) : '';
        $pc_url = isset($img['pc_url']) ? esc_url($img['pc_url']) : '';
        $mobile_url = isset($img['mobile_url']) ? esc_url($img['mobile_url']) : '';
        $img_link = isset($img['link']) ? esc_url($img['link']) : '';
        echo '<li class="cp-carousel-image-item">';
        echo '<div class="cp-carousel-image-header">';
        echo '<span>Изображение #' . ($i + 1) . '</span>';
        echo '<button type="button" class="button cp-carousel-toggle-details">Редактировать</button>';
        echo '<button type="button" class="button cp-carousel-remove-image">Удалить</button>';
        echo '</div>';
        echo '<div class="cp-carousel-image-preview">';
        echo '<img src="'.$pc_url.'" class="cp-carousel-pc-preview" style="height:40px;vertical-align:middle;margin-right:5px;max-width:80px;object-fit:cover;border:1px solid #ccc;'. (empty($pc_url) ? 'display: none;' : '') .'" />';
        echo '<img src="'.$mobile_url.'" class="cp-carousel-mobile-preview" style="height:40px;vertical-align:middle;max-width:80px;object-fit:cover;border:1px solid #ccc;'. (empty($mobile_url) ? 'display: none;' : '') .'" />';
        echo '</div>';
        echo '<div class="cp-carousel-image-details" style="display: none;">';
        echo '<p><strong>Изображение для ПК (1920x480):</strong></p>';
        echo '<input type="text" name="cp_carousel_images['.$i.'][pc_url]" value="'.$pc_url.'" placeholder="URL или выберите из библиотеки" class="cp-carousel-pc-url" style="width:60%" />';
        echo '<button type="button" class="button cp-carousel-select-media">Медиа</button> ';
        echo '<p><strong>Изображение для Мобильных (1080x720):</strong></p>';
        echo '<input type="text" name="cp_carousel_images['.$i.'][mobile_url]" value="'.$mobile_url.'" placeholder="URL или выберите из библиотеки" class="cp-carousel-mobile-url" style="width:60%" />';
        echo '<button type="button" class="button cp-carousel-select-media">Медиа</button> ';
        echo '<p><strong>Ссылка (необязательно):</strong></p>';
        echo '<input type="text" name="cp_carousel_images['.$i.'][link]" value="'.$img_link.'" placeholder="Ссылка при клике (необязательно)" style="width:90%" /> ';
        echo '</div>';
        echo '</li>';
    }
    echo '</ul></div>';
}


function cp_carousel_settings_box($post) {
    $speed = get_post_meta($post->ID, '_cp_carousel_speed', true);
    $speed = $speed ? intval($speed) : 3000;
    echo '<div id="cp-carousel-settings-admin"><label>Скорость автопрокрутки (мс): <input type="number" name="cp_carousel_speed" value="'.$speed.'" min="500" step="100" style="width:80px" /></label><br /><small>Рекомендуется 3000 (3 сек)</small><br><br><button type="button" class="button" id="cp-carousel-clear-cache">Сбросить кэш CSS/JS</button><span id="cp-carousel-cache-status" style="margin-left:10px;color:green;display:none;">Кэш сброшен!</span></div>';
    ?>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var btn = document.getElementById("cp-carousel-clear-cache");
        var status = document.getElementById("cp-carousel-cache-status");
        if(btn) {
            btn.addEventListener("click", function() {
                btn.disabled = true;
                fetch(ajaxurl, {
                    method: "POST",
                    headers: {"Content-Type": "application/x-www-form-urlencoded"},
                    body: "action=cp_carousel_clear_cache&_wpnonce="+(window.cpCarouselClearCacheNonce ? window.cpCarouselClearCacheNonce : '')
                })
                .then(r => r.json())
                .then(data => {
                    if(data.success) {
                        status.style.display = '';
                        setTimeout(function(){ status.style.display = 'none'; }, 2000);
                    }
                    btn.disabled = false;
                });
            });
        }
    });
    </script>
    <?php
}


function cp_carousel_save_post($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (isset($_POST['cp_carousel_images']) && is_array($_POST['cp_carousel_images'])) {
        $imgs = array_values(array_filter($_POST['cp_carousel_images'], function($img) {
            return !empty($img['pc_url']) || !empty($img['mobile_url']);
        }));
        update_post_meta($post_id, '_cp_carousel_images', $imgs);
    } else {
        delete_post_meta($post_id, '_cp_carousel_images');
    }
    if (isset($_POST['cp_carousel_speed'])) {
        update_post_meta($post_id, '_cp_carousel_speed', intval($_POST['cp_carousel_speed']));
    }
    
}
add_action('save_post_cp_carousel', 'cp_carousel_save_post');


function cp_carousel_admin_enqueue_scripts($hook) {
    global $post;
    if (($hook === 'post.php' || $hook === 'post-new.php') && isset($post) && $post->post_type === 'cp_carousel') {
        wp_enqueue_media();
        wp_enqueue_script('cp-carousel-admin', plugin_dir_url(__FILE__).'js/cp-carousel-admin.js', array('jquery'), null, true);
        wp_enqueue_style('cp-carousel-admin', plugin_dir_url(__FILE__).'css/cp-carousel-admin.css');
        wp_localize_script('cp-carousel-admin', 'cpCarouselClearCacheNonce', wp_create_nonce('cp_carousel_clear_cache'));
    }
}
add_action('admin_enqueue_scripts', 'cp_carousel_admin_enqueue_scripts');


function cp_carousel_enqueue_scripts() {
    // Skip loading for admin, REST API, AJAX, and cron requests
    if (is_admin() || wp_doing_ajax() || wp_doing_cron() || 
        (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }
    
    // Check for shortcode in post content and widgets
    global $post;
    $has_shortcode = false;
    
    // Check current post content
    if (is_object($post) && has_shortcode($post->post_content, 'cp_carousel')) {
        $has_shortcode = true;
    }
    
    // Check widgets for shortcode
    if (!$has_shortcode) {
        $widget_content = '';
        $sidebars = wp_get_sidebars_widgets();
        foreach ($sidebars as $sidebar => $widgets) {
            if (is_array($widgets)) {
                foreach ($widgets as $widget) {
                    $widget_instance = get_option('widget_' . $widget);
                    if (is_array($widget_instance)) {
                        $widget_content .= serialize($widget_instance);
                    }
                }
            }
        }
        if (strpos($widget_content, '[cp_carousel') !== false) {
            $has_shortcode = true;
        }
    }
    
    // Only enqueue if shortcode is found
    if (!$has_shortcode) {
        return;
    }
    
    $ver = get_option('cp_carousel_cache_version', 1);
    wp_enqueue_style('swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css');
    wp_enqueue_script('swiper', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), null, true);
    wp_enqueue_style('cp-carousel', plugin_dir_url(__FILE__).'css/cp-carousel.css', array(), $ver);
    wp_enqueue_script('cp-carousel', plugin_dir_url(__FILE__).'js/cp-carousel.js', array('swiper'), $ver, true);
    wp_localize_script('cp-carousel', 'cpCarouselAjax', array(
        'url' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'cp_carousel_enqueue_scripts');


function cp_carousel_ajax_get() {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $images = get_post_meta($id, '_cp_carousel_images', true);
    $speed = get_post_meta($id, '_cp_carousel_speed', true);
    wp_send_json(array(
        'images' => is_array($images) ? array_map(function($img) {
            return [
                'pc_url' => isset($img['pc_url']) ? esc_url($img['pc_url']) : '',
                'mobile_url' => isset($img['mobile_url']) ? esc_url($img['mobile_url']) : '',
                'link' => isset($img['link']) ? esc_url($img['link']) : '',
            ];
        }, $images) : array(),
        'speed' => $speed ? intval($speed) : 3000
    ));
}
add_action('wp_ajax_cp_carousel_get', 'cp_carousel_ajax_get');


add_action('wp_ajax_nopriv_cp_carousel_get', 'cp_carousel_ajax_get');


function cp_carousel_ajax_clear_cache() {
    check_ajax_referer('cp_carousel_clear_cache');
    $ver = (int)get_option('cp_carousel_cache_version', 1);
    $ver++;
    update_option('cp_carousel_cache_version', $ver);
    wp_send_json_success(array('version' => $ver));
}
add_action('wp_ajax_cp_carousel_clear_cache', 'cp_carousel_ajax_clear_cache');


function cp_carousel_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => 0
    ), $atts);
    $carousel_id = intval($atts['id']);

    $output = '<div class="cp-carousel" data-id="'.$carousel_id.'"></div>';
    return $output;
}
add_shortcode('cp_carousel', 'cp_carousel_shortcode');